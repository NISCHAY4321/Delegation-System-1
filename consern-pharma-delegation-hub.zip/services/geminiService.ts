
import { GoogleGenAI, Type } from "@google/genai";
import { Task } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export const geminiService = {
  summarizePerformance: async (tasks: Task[], userName: string) => {
    const summaryData = tasks.map(t => ({
      title: t.title,
      status: t.status,
      priority: t.priority,
      due: t.dueDate
    }));

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze the following task list for ${userName} and provide a 2-sentence performance summary and one actionable recommendation: ${JSON.stringify(summaryData)}`,
        config: {
          temperature: 0.7,
        }
      });
      return response.text || "No summary available.";
    } catch (error) {
      console.error("Gemini Error:", error);
      return "Unable to generate AI summary at this time.";
    }
  },

  suggestTaskDescription: async (title: string) => {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Provide a professional, concise description for an enterprise task titled: "${title}"`,
        config: {
          temperature: 0.7,
        }
      });
      return response.text || "";
    } catch (error) {
      return "";
    }
  }
};
