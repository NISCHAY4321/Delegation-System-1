
import { User, Task, Role, TaskStatus, Priority, AppSettings } from '../types';

const STORAGE_KEY_USERS = 'delegation_hub_users';
const STORAGE_KEY_TASKS = 'delegation_hub_tasks';
const STORAGE_KEY_SETTINGS = 'delegation_hub_settings';

const generateToken = () => {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

const DEFAULT_TEMPLATES = {
  taskAssigned: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
    <div style="background-color: #2563eb; color: white; padding: 24px; text-align: center;">
      <h1 style="margin: 0; font-size: 24px;">New Task Assigned</h1>
    </div>
    <div style="padding: 32px; color: #1e293b; line-height: 1.6;">
      <p>Hello <strong>{{name}}</strong>,</p>
      <p>A new task has been assigned to you in Enterprise Delegation Hub.</p>
      <div style="background-color: #f8fafc; padding: 16px; border-radius: 8px; margin: 24px 0;">
        <p style="margin: 0;"><strong>Task:</strong> {{taskTitle}}</p>
        <p style="margin: 8px 0 0 0;"><strong>Priority:</strong> {{priority}}</p>
        <p style="margin: 8px 0 0 0;"><strong>Due Date:</strong> {{dueDate}}</p>
      </div>
      <a href="{{appUrl}}" style="display: inline-block; background-color: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">View My Tasks</a>
    </div>
  </div>`,
  taskCompleted: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
    <div style="background-color: #10b981; color: white; padding: 24px; text-align: center;">
      <h1 style="margin: 0; font-size: 24px;">Task Completed</h1>
    </div>
    <div style="padding: 32px; color: #1e293b; line-height: 1.6;">
      <p>Hello <strong>{{creatorName}}</strong>,</p>
      <p>The task <strong>{{taskTitle}}</strong> has been marked as completed by {{delegateName}}.</p>
      <div style="background-color: #f8fafc; padding: 16px; border-radius: 8px; margin: 24px 0;">
        <p style="margin: 0;">Status: <strong>Finished</strong></p>
      </div>
      <a href="{{appUrl}}" style="display: inline-block; background-color: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">Check Dashboard</a>
    </div>
  </div>`,
  pendingVerification: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden;">
    <div style="background-color: #8b5cf6; color: white; padding: 24px; text-align: center;">
      <h1 style="margin: 0; font-size: 24px;">Verification Required</h1>
    </div>
    <div style="padding: 32px; color: #1e293b; line-height: 1.6;">
      <p>Hello <strong>{{creatorName}}</strong>,</p>
      <p>A task delegated to {{delegateName}} requires your final verification.</p>
      <div style="background-color: #f8fafc; padding: 16px; border-radius: 8px; margin: 24px 0;">
        <p style="margin: 0;"><strong>Task:</strong> {{taskTitle}}</p>
      </div>
      <p>Click below to securely verify and close this task:</p>
      <a href="{{verifyUrl}}" style="display: inline-block; background-color: #8b5cf6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">Verify Securely</a>
    </div>
  </div>`
};

export const db = {
  getUsers: (): User[] => {
    const data = localStorage.getItem(STORAGE_KEY_USERS);
    return data ? JSON.parse(data) : [];
  },

  saveUsers: (users: User[]) => {
    localStorage.setItem(STORAGE_KEY_USERS, JSON.stringify(users));
  },

  getTasks: (): Task[] => {
    const data = localStorage.getItem(STORAGE_KEY_TASKS);
    return data ? JSON.parse(data) : [];
  },

  saveTasks: (tasks: Task[]) => {
    localStorage.setItem(STORAGE_KEY_TASKS, JSON.stringify(tasks));
  },

  getSettings: (): AppSettings => {
    const data = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (data) return JSON.parse(data);
    return {
      whatsapp: { phoneNumberId: '', accessToken: '', wabaId: '', verifyToken: '' },
      emailTemplates: DEFAULT_TEMPLATES
    };
  },

  saveSettings: (settings: AppSettings) => {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  },

  initialize: () => {
    const users = db.getUsers();
    if (users.length === 0) {
      console.log("Database initialized. Waiting for first admin.");
    }
  },

  upsertUser: (user: User) => {
    const users = db.getUsers();
    const index = users.findIndex(u => u.email === user.email);
    if (index > -1) {
      users[index] = user;
    } else {
      users.push(user);
    }
    db.saveUsers(users);
  },

  createTask: (task: Omit<Task, 'id' | 'createdAt' | 'status' | 'verificationToken'>): Task => {
    const tasks = db.getTasks();
    const newTask: Task = {
      ...task,
      id: `T-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString(),
      status: TaskStatus.OPEN,
      verificationToken: generateToken()
    };
    tasks.unshift(newTask);
    db.saveTasks(tasks);
    return newTask;
  },

  updateTask: (taskId: string, updates: Partial<Task>) => {
    const tasks = db.getTasks();
    const index = tasks.findIndex(t => t.id === taskId);
    if (index > -1) {
      tasks[index] = { ...tasks[index], ...updates };
      db.saveTasks(tasks);
    }
  }
};
