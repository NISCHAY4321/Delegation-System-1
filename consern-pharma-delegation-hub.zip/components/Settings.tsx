
import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { AppSettings } from '../types';
import { 
  Save, 
  Smartphone, 
  Mail, 
  Eye, 
  CheckCircle2, 
  AlertCircle,
  Code,
  Layout,
  ChevronRight
} from 'lucide-react';

const Settings: React.FC = () => {
  const [settings, setSettings] = useState<AppSettings>(db.getSettings());
  const [activeSubTab, setActiveSubTab] = useState<'whatsapp' | 'email'>('whatsapp');
  const [showPreview, setShowPreview] = useState<keyof AppSettings['emailTemplates'] | null>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  const handleSave = () => {
    setSaveStatus('saving');
    db.saveSettings(settings);
    setTimeout(() => {
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    }, 800);
  };

  const updateWhatsapp = (field: keyof AppSettings['whatsapp'], value: string) => {
    setSettings({
      ...settings,
      whatsapp: { ...settings.whatsapp, [field]: value }
    });
  };

  const updateTemplate = (key: keyof AppSettings['emailTemplates'], value: string) => {
    setSettings({
      ...settings,
      emailTemplates: { ...settings.emailTemplates, [key]: value }
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">System Settings</h1>
          <p className="text-gray-500 mt-1">Configure external integrations and notification channels.</p>
        </div>
        <button
          onClick={handleSave}
          disabled={saveStatus === 'saving'}
          className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-100 font-bold hover:bg-blue-700 transition-all active:scale-95 disabled:opacity-50"
        >
          {saveStatus === 'saved' ? (
            <><CheckCircle2 className="w-5 h-5 mr-2" /> Saved</>
          ) : (
            <><Save className="w-5 h-5 mr-2" /> {saveStatus === 'saving' ? 'Saving...' : 'Save Settings'}</>
          )}
        </button>
      </header>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Navigation */}
        <div className="lg:w-64 flex flex-col gap-2">
          <button
            onClick={() => setActiveSubTab('whatsapp')}
            className={`flex items-center justify-between px-4 py-3 rounded-xl transition-all font-medium ${
              activeSubTab === 'whatsapp' ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            <div className="flex items-center">
              <Smartphone className="w-5 h-5 mr-3" />
              WhatsApp API
            </div>
            <ChevronRight className="w-4 h-4 opacity-50" />
          </button>
          <button
            onClick={() => setActiveSubTab('email')}
            className={`flex items-center justify-between px-4 py-3 rounded-xl transition-all font-medium ${
              activeSubTab === 'email' ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            <div className="flex items-center">
              <Mail className="w-5 h-5 mr-3" />
              Email Templates
            </div>
            <ChevronRight className="w-4 h-4 opacity-50" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 space-y-6">
          {activeSubTab === 'whatsapp' ? (
            <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm space-y-6">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-green-50 text-green-600 rounded-lg">
                  <Smartphone className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Meta Business API Configuration</h3>
              </div>
              <p className="text-sm text-gray-500 max-w-2xl leading-relaxed">
                Enter your WhatsApp Business Platform credentials to enable automated task notifications. 
                Generate these from the <a href="https://developers.facebook.com" className="text-blue-600 font-semibold hover:underline">Meta Developer Portal</a>.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Phone Number ID</label>
                  <input
                    type="text"
                    value={settings.whatsapp.phoneNumberId}
                    onChange={(e) => updateWhatsapp('phoneNumberId', e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="e.g. 104253165..."
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">WABA ID (WhatsApp Business Account ID)</label>
                  <input
                    type="text"
                    value={settings.whatsapp.wabaId}
                    onChange={(e) => updateWhatsapp('wabaId', e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="e.g. 1223456..."
                  />
                </div>
                <div className="col-span-full space-y-2">
                  <label className="text-sm font-bold text-gray-700">Permanent Access Token</label>
                  <input
                    type="password"
                    value={settings.whatsapp.accessToken}
                    onChange={(e) => updateWhatsapp('accessToken', e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="EAAGz..."
                  />
                </div>
                <div className="col-span-full space-y-2">
                  <label className="text-sm font-bold text-gray-700">Webhook Verify Token (Optional)</label>
                  <input
                    type="text"
                    value={settings.whatsapp.verifyToken}
                    onChange={(e) => updateWhatsapp('verifyToken', e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
                    placeholder="Any custom string"
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm space-y-8">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                    <Layout className="w-5 h-5" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">HTML Notification Templates</h3>
                </div>
                <button 
                  onClick={() => setShowPreview('taskAssigned')}
                  className="text-sm font-bold text-blue-600 flex items-center gap-1.5 hover:bg-blue-50 px-3 py-1.5 rounded-lg transition-colors"
                >
                  <Eye className="w-4 h-4" />
                  See Templates Preview
                </button>
              </div>

              <div className="space-y-6">
                {([
                  { key: 'taskAssigned', label: 'Task Assigned Template', icon: Smartphone },
                  { key: 'taskCompleted', label: 'Task Completed Template', icon: CheckCircle2 },
                  { key: 'pendingVerification', label: 'Pending Verification Template', icon: AlertCircle },
                ] as const).map(({ key, label, icon: Icon }) => (
                  <div key={key} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <Icon className="w-4 h-4 text-blue-600" />
                        {label}
                      </label>
                      <button 
                        onClick={() => setShowPreview(key)}
                        className="text-xs text-gray-400 hover:text-blue-600 font-medium"
                      >
                        Preview {key}
                      </button>
                    </div>
                    <div className="relative group">
                      <Code className="absolute right-4 top-4 w-4 h-4 text-gray-300 group-hover:text-blue-400 transition-colors" />
                      <textarea
                        value={settings.emailTemplates[key]}
                        onChange={(e) => updateTemplate(key, e.target.value)}
                        className="w-full px-4 py-4 rounded-2xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-xs h-32 resize-none"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
          <div className="bg-white w-full max-w-3xl rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">Template Preview: {showPreview}</h2>
              <button 
                onClick={() => setShowPreview(null)}
                className="p-2 hover:bg-gray-100 rounded-full text-gray-400"
              >&times;</button>
            </div>
            <div className="flex-1 overflow-y-auto p-12 bg-gray-50">
              <div 
                className="bg-white shadow-sm rounded-xl overflow-hidden"
                dangerouslySetInnerHTML={{ 
                  __html: settings.emailTemplates[showPreview]
                    .replace('{{name}}', 'John Doe')
                    .replace('{{creatorName}}', 'Jane Boss')
                    .replace('{{delegateName}}', 'John Doe')
                    .replace('{{taskTitle}}', 'Q3 Sales Report Finalization')
                    .replace('{{priority}}', 'High')
                    .replace('{{dueDate}}', '2023-10-30')
                    .replace('{{appUrl}}', '#')
                    .replace('{{verifyUrl}}', '#')
                }} 
              />
            </div>
            <div className="p-6 border-t border-gray-100 text-center">
              <p className="text-xs text-gray-400 italic">This is a mockup preview with sample data placeholders replaced.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Settings;
