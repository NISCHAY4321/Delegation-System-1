
import React, { useState, useEffect } from 'react';
import { User, Role } from '../types';
import { db } from '../services/db';
import { UserPlus, UserX, UserCheck, Shield, ChevronRight, Search, Mail, Key, Users as UsersIcon, Check } from 'lucide-react';

const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const refreshUsers = () => {
    setUsers(db.getUsers());
  };

  useEffect(() => {
    refreshUsers();
  }, []);

  const toggleUserStatus = (email: string) => {
    const updatedUsers = users.map(u => {
      if (u.email === email) {
        return { ...u, status: u.status === 'Active' ? 'Inactive' : 'Active' } as User;
      }
      return u;
    });
    db.saveUsers(updatedUsers);
    setUsers(updatedUsers);
  };

  const handleSaveUser = (newUser: User, subordinateEmails: string[]) => {
    // 1. Add the new user
    db.upsertUser(newUser);

    // 2. Update parentEmail for all selected subordinates
    const allUsers = db.getUsers();
    const updatedUsers = allUsers.map(u => {
      if (subordinateEmails.includes(u.email)) {
        return { ...u, parentEmail: newUser.email };
      }
      return u;
    });
    
    db.saveUsers(updatedUsers);
    refreshUsers();
    setShowAddModal(false);
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
          <p className="text-gray-500 mt-1">Manage platform roles and delegation hierarchies.</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-100 font-bold hover:bg-blue-700 transition-all active:scale-95"
        >
          <UserPlus className="w-5 h-5 mr-2" />
          Add User
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-100 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none border-none transition-all"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 text-gray-500 text-xs uppercase font-bold tracking-wider">
                <th className="px-8 py-4">User</th>
                <th className="px-6 py-4">Role</th>
                <th className="px-6 py-4">Managed By</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-8 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredUsers.map((user) => (
                <tr key={user.email} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-lg">
                        {user.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">{user.name}</p>
                        <p className="text-sm text-gray-500">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    <div className="flex items-center gap-2">
                      <Shield className={`w-4 h-4 ${user.role === Role.ADMIN ? 'text-red-500' : 'text-blue-500'}`} />
                      <span className="text-sm font-semibold">{user.role}</span>
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    <p className="text-sm text-gray-600">{user.parentEmail || '-'}</p>
                  </td>
                  <td className="px-6 py-6">
                    <span className={`px-3 py-1 text-xs font-bold rounded-full ${
                      user.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <button
                      onClick={() => toggleUserStatus(user.email)}
                      className={`p-2 rounded-xl transition-all ${
                        user.status === 'Active' 
                          ? 'text-red-600 hover:bg-red-50' 
                          : 'text-green-600 hover:bg-green-50'
                      }`}
                      title={user.status === 'Active' ? 'Deactivate User' : 'Activate User'}
                    >
                      {user.status === 'Active' ? <UserX className="w-5 h-5" /> : <UserCheck className="w-5 h-5" />}
                    </button>
                    <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl ml-2">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <AddUserModal 
          onClose={() => setShowAddModal(false)} 
          onSave={handleSaveUser}
          existingUsers={users}
        />
      )}
    </div>
  );
};

interface AddUserModalProps {
  onClose: () => void;
  onSave: (user: User, subordinates: string[]) => void;
  existingUsers: User[];
}

const AddUserModal: React.FC<AddUserModalProps> = ({ onClose, onSave, existingUsers }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: Role.DELEGATE,
    password: 'password123'
  });
  const [subordinateEmails, setSubordinateEmails] = useState<string[]>([]);
  const [showSubSelect, setShowSubSelect] = useState(false);

  const isHierarchicalRole = formData.role === Role.DELEGATOR || formData.role === Role.BOSS || formData.role === Role.ADMIN;

  const toggleSubordinate = (email: string) => {
    setSubordinateEmails(prev => 
      prev.includes(email) ? prev.filter(e => e !== email) : [...prev, email]
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-8 border-b border-gray-100">
          <h2 className="text-2xl font-bold text-gray-900">Add New System User</h2>
          <p className="text-sm text-gray-500 mt-1">Configure credentials and initial role.</p>
        </div>
        <form onSubmit={(e) => {
          e.preventDefault();
          onSave({ ...formData, id: `u-${Date.now()}`, status: 'Active' }, subordinateEmails);
        }} className="p-8 space-y-6 max-h-[80vh] overflow-y-auto">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Full Name</label>
              <div className="relative">
                <UsersIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="Employee Name"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Work Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="email@company.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Initial Password</label>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none bg-gray-50"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">System Role</label>
              <select
                value={formData.role}
                onChange={(e) => {
                  const newRole = e.target.value as Role;
                  setFormData({ ...formData, role: newRole });
                  if (newRole === Role.DELEGATE) setSubordinateEmails([]);
                }}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none bg-white font-medium"
              >
                {Object.values(Role).map(role => (
                  <option key={role} value={role}>{role}</option>
                ))}
              </select>
            </div>

            {isHierarchicalRole && (
              <div className="pt-2 animate-in slide-in-from-top-2 duration-300">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Assign Subordinates</label>
                <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100 max-h-48 overflow-y-auto space-y-2">
                  {existingUsers.length > 0 ? (
                    existingUsers.filter(u => u.email !== formData.email).map(user => (
                      <div 
                        key={user.email} 
                        onClick={() => toggleSubordinate(user.email)}
                        className={`flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${
                          subordinateEmails.includes(user.email) ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-white hover:bg-gray-100 border-transparent'
                        } border`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-gray-200 flex items-center justify-center text-xs font-bold uppercase">
                            {user.name.charAt(0)}
                          </div>
                          <div>
                            <p className="text-xs font-bold truncate max-w-[150px]">{user.name}</p>
                            <p className="text-[10px] opacity-70 truncate max-w-[150px]">{user.email}</p>
                          </div>
                        </div>
                        {subordinateEmails.includes(user.email) && <Check className="w-4 h-4" />}
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-gray-400 italic p-2 text-center">No other users to assign yet.</p>
                  )}
                </div>
                <p className="text-[11px] text-gray-400 mt-2 px-1">Selected: {subordinateEmails.length} users will report to this {formData.role}.</p>
              </div>
            )}
          </div>

          <div className="flex gap-4 pt-4 sticky bottom-0 bg-white">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-4 bg-gray-50 text-gray-600 font-bold rounded-2xl hover:bg-gray-100 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 shadow-xl shadow-blue-100 transition-all active:scale-[0.98]"
            >
              Register User
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UserManagement;
