
import React from 'react';
import { User, Role } from '../types';
import { 
  LayoutDashboard, 
  ClipboardList, 
  Send, 
  CheckCircle2, 
  Users, 
  Settings, 
  LogOut,
  BarChart3
} from 'lucide-react';

interface LayoutProps {
  user: User;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ user, onLogout, activeTab, setActiveTab, children }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: [Role.ADMIN, Role.BOSS, Role.DELEGATOR, Role.DELEGATE] },
    { id: 'my-tasks', label: 'My Tasks', icon: ClipboardList, roles: [Role.ADMIN, Role.BOSS, Role.DELEGATOR, Role.DELEGATE] },
    { id: 'delegated', label: 'Tasks Delegated', icon: Send, roles: [Role.ADMIN, Role.BOSS, Role.DELEGATOR] },
    { id: 'verification', label: 'Verification', icon: CheckCircle2, roles: [Role.ADMIN, Role.BOSS, Role.DELEGATOR] },
    { id: 'reports', label: 'MIS Reports', icon: BarChart3, roles: [Role.ADMIN, Role.BOSS] },
    { id: 'users', label: 'User Management', icon: Users, roles: [Role.ADMIN] },
    { id: 'settings', label: 'Settings', icon: Settings, roles: [Role.ADMIN] },
  ];

  const filteredMenu = menuItems.filter(item => item.roles.includes(user.role));

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-200">
        <div className="p-6">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            DelegationHub
          </h1>
        </div>
        <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
          {filteredMenu.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center w-full px-4 py-3 text-sm font-medium rounded-xl transition-all ${
                activeTab === item.id
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
              }`}
            >
              <item.icon className="w-5 h-5 mr-3" />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-gray-200">
          <div className="flex items-center px-4 py-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-lg">
              {user.name.charAt(0)}
            </div>
            <div className="ml-3 overflow-hidden">
              <p className="text-sm font-semibold text-gray-900 truncate">{user.name}</p>
              <p className="text-xs text-gray-500 truncate">{user.role}</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center w-full px-4 py-3 text-sm font-medium text-red-600 rounded-xl hover:bg-red-50 transition-all"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header - Mobile */}
        <header className="md:hidden flex items-center justify-between px-6 py-4 bg-white border-b border-gray-200">
          <h1 className="text-xl font-bold text-blue-600">DelegationHub</h1>
          <button onClick={onLogout} className="p-2 text-gray-500 hover:text-red-600">
            <LogOut className="w-6 h-6" />
          </button>
        </header>

        {/* Dynamic Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 md:p-10">
          {children}
        </div>

        {/* Bottom Nav - Mobile */}
        <nav className="md:hidden flex justify-around p-3 bg-white border-t border-gray-200">
          {filteredMenu.slice(0, 4).map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center p-2 rounded-lg ${
                activeTab === item.id ? 'text-blue-600' : 'text-gray-400'
              }`}
            >
              <item.icon className="w-6 h-6" />
              <span className="text-[10px] mt-1">{item.label}</span>
            </button>
          ))}
        </nav>
      </main>
    </div>
  );
};

export default Layout;
