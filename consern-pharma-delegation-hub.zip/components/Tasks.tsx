
import React, { useState, useEffect } from 'react';
import { User, Task, Role, Priority, TaskStatus } from '../types';
import { db } from '../services/db';
import { geminiService } from '../services/geminiService';
import { PRIORITY_COLORS, STATUS_COLORS } from '../constants';
import { 
  Plus, Search, Filter, Calendar, 
  MoreVertical, Clock, CheckCircle2, 
  User as UserIcon, AlertTriangle, Sparkles, Wand2, Link as LinkIcon, ShieldCheck, Copy, Check
} from 'lucide-react';

interface TasksProps {
  user: User;
  view: 'my-tasks' | 'delegated' | 'verification';
}

const Tasks: React.FC<TasksProps> = ({ user, view }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<User[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    refreshTasks();
    setUsers(db.getUsers());
  }, [user, view]);

  const refreshTasks = () => {
    const all = db.getTasks();
    let filtered = [];
    if (view === 'my-tasks') {
      filtered = all.filter(t => t.delegateEmail === user.email);
    } else if (view === 'delegated') {
      filtered = all.filter(t => t.creatorEmail === user.email);
    } else if (view === 'verification') {
      filtered = all.filter(t => t.creatorEmail === user.email && t.status === TaskStatus.PENDING_VERIFICATION);
    }
    setTasks(filtered);
  };

  const handleStatusChange = (taskId: string, newStatus: TaskStatus) => {
    db.updateTask(taskId, { 
      status: newStatus,
      completedAt: newStatus === TaskStatus.COMPLETED ? new Date().toISOString() : undefined 
    });
    refreshTasks();
  };

  const handleVerify = (taskId: string) => {
    db.updateTask(taskId, { 
      status: TaskStatus.COMPLETED, 
      verifiedAt: new Date().toISOString() 
    });
    refreshTasks();
  };

  const copyVerificationLink = (task: Task) => {
    const baseUrl = window.location.origin + window.location.pathname;
    const verifyUrl = `${baseUrl}#verify/${task.id}/${task.verificationToken}`;
    navigator.clipboard.writeText(verifyUrl).then(() => {
      setCopiedId(task.id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const filteredTasks = tasks.filter(t => 
    t.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            {view === 'my-tasks' ? 'Assigned to Me' : view === 'delegated' ? 'Delegated by Me' : 'Pending Verification'}
          </h1>
          <p className="text-gray-500 mt-1">{filteredTasks.length} total tasks found.</p>
        </div>
        {view === 'delegated' && user.role !== Role.DELEGATE && (
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl shadow-lg shadow-blue-200 transition-all active:scale-95"
          >
            <Plus className="w-5 h-5 mr-2" />
            Create Task
          </button>
        )}
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search tasks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
          />
        </div>
        <button className="flex items-center px-4 py-3 bg-white border border-gray-200 rounded-2xl text-gray-600 hover:bg-gray-50 transition-all">
          <Filter className="w-5 h-5 mr-2" />
          Filter
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredTasks.map((task) => (
          <div key={task.id} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow group">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <span className={`px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-full border ${PRIORITY_COLORS[task.priority]}`}>
                    {task.priority}
                  </span>
                  <span className={`px-3 py-1 text-xs font-bold rounded-full ${STATUS_COLORS[task.status]}`}>
                    {task.status}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-gray-900 group-hover:text-blue-600 transition-colors">{task.title}</h3>
                <p className="text-gray-500 mt-2 text-sm leading-relaxed">{task.description}</p>
                
                <div className="flex flex-wrap items-center gap-6 mt-6">
                  <div className="flex items-center text-sm text-gray-400">
                    <UserIcon className="w-4 h-4 mr-2" />
                    <span className="font-medium text-gray-600">{view === 'my-tasks' ? 'From: ' : 'To: '}</span>
                    <span className="ml-1">{view === 'my-tasks' ? task.creatorEmail : task.delegateEmail}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-400">
                    <Clock className="w-4 h-4 mr-2" />
                    <span className="font-medium text-gray-600">Due:</span>
                    <span className="ml-1 text-gray-900">{new Date(task.dueDate).toLocaleDateString()}</span>
                  </div>
                  {task.verificationRequired && (
                    <div className="flex items-center text-xs text-purple-600 bg-purple-50 px-2 py-1 rounded-lg font-medium">
                      <ShieldCheck className="w-3 h-3 mr-1" />
                      Tokenized Verification
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col justify-center items-end gap-3 min-w-[180px]">
                {view === 'my-tasks' && task.status !== TaskStatus.COMPLETED && task.status !== TaskStatus.PENDING_VERIFICATION && (
                  <button
                    onClick={() => handleStatusChange(task.id, task.verificationRequired ? TaskStatus.PENDING_VERIFICATION : TaskStatus.COMPLETED)}
                    className="w-full px-4 py-2 bg-green-500 hover:bg-green-600 text-white font-semibold rounded-xl shadow-lg shadow-green-100 transition-all flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Complete
                  </button>
                )}
                
                {view === 'verification' && task.status === TaskStatus.PENDING_VERIFICATION && (
                  <>
                    <button
                      onClick={() => handleVerify(task.id)}
                      className="w-full px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-xl shadow-lg shadow-purple-100 transition-all flex items-center justify-center gap-2"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      Verify & Close
                    </button>
                    <button
                      onClick={() => copyVerificationLink(task)}
                      className={`w-full px-4 py-2 border font-semibold rounded-xl transition-all flex items-center justify-center gap-2 ${
                        copiedId === task.id ? 'bg-green-50 border-green-200 text-green-600' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      {copiedId === task.id ? <Check className="w-4 h-4" /> : <LinkIcon className="w-4 h-4" />}
                      {copiedId === task.id ? 'Copied' : 'Copy Link'}
                    </button>
                  </>
                )}

                <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-all">
                  <MoreVertical className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
        {filteredTasks.length === 0 && (
          <div className="text-center py-20 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
            <p className="text-gray-400">No tasks found matching your criteria.</p>
          </div>
        )}
      </div>

      {showModal && (
        <TaskForm 
          onClose={() => setShowModal(false)} 
          onSave={() => { setShowModal(false); refreshTasks(); }} 
          users={users} 
          creator={user}
        />
      )}
    </div>
  );
};

interface TaskFormProps {
  onClose: () => void;
  onSave: () => void;
  users: User[];
  creator: User;
}

const TaskForm: React.FC<TaskFormProps> = ({ onClose, onSave, users, creator }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    delegateEmail: '',
    priority: Priority.MEDIUM,
    dueDate: new Date().toISOString().split('T')[0],
    verificationRequired: true
  });
  const [loadingAi, setLoadingAi] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    db.createTask({
      ...formData,
      creatorEmail: creator.email
    });
    onSave();
  };

  const generateAiDescription = async () => {
    if (!formData.title) return;
    setLoadingAi(true);
    const desc = await geminiService.suggestTaskDescription(formData.title);
    setFormData(prev => ({ ...prev, description: desc }));
    setLoadingAi(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-8 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Create New Task</h2>
            <p className="text-sm text-gray-500">Quickly delegate responsibilities with AI help.</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-400">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="col-span-full">
              <label className="block text-sm font-semibold text-gray-700 mb-1">Task Title</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  onBlur={generateAiDescription}
                  className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none pr-12"
                  placeholder="e.g., Finalize Monthly Budget Sheet"
                />
                <button 
                  type="button"
                  onClick={generateAiDescription}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
                  title="AI Suggestions"
                >
                  <Sparkles className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="col-span-full">
              <label className="block text-sm font-semibold text-gray-700 mb-1">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none h-24 resize-none"
                placeholder={loadingAi ? "AI is thinking..." : "Details about the task..."}
                disabled={loadingAi}
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Assign To</label>
              <select
                required
                value={formData.delegateEmail}
                onChange={(e) => setFormData({ ...formData, delegateEmail: e.target.value })}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="">Select User</option>
                {users.filter(u => u.email !== creator.email).map(u => (
                  <option key={u.id} value={u.email}>{u.name} ({u.role})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Due Date</label>
              <input
                type="date"
                required
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">Priority</label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value as Priority })}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none"
              >
                {Object.values(Priority).map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center">
              <label className="flex items-center cursor-pointer group">
                <div className="relative">
                  <input
                    type="checkbox"
                    className="sr-only"
                    checked={formData.verificationRequired}
                    onChange={(e) => setFormData({ ...formData, verificationRequired: e.target.checked })}
                  />
                  <div className={`w-12 h-7 rounded-full transition-colors ${formData.verificationRequired ? 'bg-blue-600' : 'bg-gray-300'}`}></div>
                  <div className={`absolute left-1 top-1 w-5 h-5 bg-white rounded-full transition-transform ${formData.verificationRequired ? 'translate-x-5' : 'translate-x-0'}`}></div>
                </div>
                <span className="ml-3 text-sm font-semibold text-gray-700">Verification Required</span>
              </label>
            </div>
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-4 bg-gray-50 text-gray-600 font-bold rounded-2xl hover:bg-gray-100 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 shadow-xl shadow-blue-200 transition-all active:scale-[0.98]"
            >
              Create Task
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Tasks;
