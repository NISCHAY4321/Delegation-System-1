
import React, { useState, useEffect } from 'react';
import { User, Task, TaskStatus } from '../types';
import { db } from '../services/db';
import { geminiService } from '../services/geminiService';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { BrainCircuit, Sparkles, TrendingUp, Clock, AlertCircle } from 'lucide-react';

interface DashboardProps {
  user: User;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [aiSummary, setAiSummary] = useState<string>('Generating AI performance insights...');

  useEffect(() => {
    const allTasks = db.getTasks();
    const filtered = allTasks.filter(t => 
      t.delegateEmail === user.email || t.creatorEmail === user.email
    );
    setTasks(filtered);

    const loadAi = async () => {
      if (filtered.length > 0) {
        const summary = await geminiService.summarizePerformance(filtered, user.name);
        setAiSummary(summary);
      } else {
        setAiSummary("Start delegating tasks to see AI insights.");
      }
    };
    loadAi();
  }, [user]);

  const stats = {
    total: tasks.length,
    completed: tasks.filter(t => t.status === TaskStatus.COMPLETED).length,
    pending: tasks.filter(t => t.status === TaskStatus.OPEN || t.status === TaskStatus.IN_PROGRESS).length,
    verification: tasks.filter(t => t.status === TaskStatus.PENDING_VERIFICATION).length,
    overdue: tasks.filter(t => t.status === TaskStatus.OVERDUE).length,
  };

  const pieData = [
    { name: 'Completed', value: stats.completed, color: '#10B981' },
    { name: 'Pending', value: stats.pending, color: '#3B82F6' },
    { name: 'Needs Verification', value: stats.verification, color: '#8B5CF6' },
    { name: 'Overdue', value: stats.overdue, color: '#EF4444' },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Overview</h1>
          <p className="text-gray-500 mt-1">Real-time enterprise delegation analytics for {user.name}.</p>
        </div>
      </header>

      {/* AI Card */}
      <div className="bg-gradient-to-br from-indigo-600 via-blue-600 to-blue-700 rounded-3xl p-6 text-white shadow-xl shadow-blue-100 flex flex-col md:flex-row items-center gap-6">
        <div className="bg-white/10 p-4 rounded-2xl backdrop-blur-md">
          <BrainCircuit className="w-12 h-12" />
        </div>
        <div className="flex-1">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            AI Assistant Insights <Sparkles className="w-4 h-4" />
          </h3>
          <p className="mt-2 text-blue-50 leading-relaxed max-w-2xl">
            {aiSummary}
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Completion Rate', val: `${stats.total > 0 ? Math.round((stats.completed/stats.total)*100) : 0}%`, icon: TrendingUp, color: 'blue' },
          { label: 'Active Tasks', val: stats.pending, icon: Clock, color: 'blue' },
          { label: 'Needs Verification', val: stats.verification, icon: CheckCircle2, color: 'purple' },
          { label: 'Overdue', val: stats.overdue, icon: AlertCircle, color: 'red' },
        ].map((s, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex items-center gap-4">
            <div className={`w-12 h-12 rounded-2xl bg-${s.color}-50 flex items-center justify-center`}>
              <s.icon className={`w-6 h-6 text-${s.color}-600`} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">{s.label}</p>
              <p className="text-2xl font-bold text-gray-900">{s.val}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Task Distribution</h3>
          <div className="h-[300px]">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-400 italic">No task data to display</div>
            )}
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Weekly Productivity</h3>
          <div className="h-[300px]">
             <ResponsiveContainer width="100%" height="100%">
                <BarChart data={[
                  { day: 'Mon', count: 4 },
                  { day: 'Tue', count: 7 },
                  { day: 'Wed', count: 5 },
                  { day: 'Thu', count: 9 },
                  { day: 'Fri', count: 12 },
                ]}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="day" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} />
                  <Tooltip cursor={{fill: '#f8fafc'}} />
                  <Bar dataKey="count" fill="#3B82F6" radius={[4, 4, 0, 0]} barSize={40} />
                </BarChart>
              </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

// Internal Import helper
import { CheckCircle2 } from 'lucide-react';

export default Dashboard;
