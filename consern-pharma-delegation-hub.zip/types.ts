
export enum Role {
  ADMIN = 'Admin',
  BOSS = 'Boss',
  DELEGATOR = 'Delegator',
  DELEGATE = 'Delegate'
}

export enum TaskStatus {
  OPEN = 'Open',
  IN_PROGRESS = 'In Progress',
  PENDING_VERIFICATION = 'Pending Verification',
  COMPLETED = 'Completed',
  OVERDUE = 'Overdue'
}

export enum Priority {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High',
  CRITICAL = 'Critical'
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
  status: 'Active' | 'Inactive';
  password?: string;
  parentEmail?: string; // For Delegator mapping
}

export interface Task {
  id: string;
  title: string;
  description: string;
  creatorEmail: string;
  delegateEmail: string;
  priority: Priority;
  status: TaskStatus;
  createdAt: string;
  dueDate: string;
  verificationRequired: boolean;
  verificationToken?: string;
  verifiedAt?: string;
  completedAt?: string;
}

export interface AppSettings {
  whatsapp: {
    phoneNumberId: string;
    accessToken: string;
    wabaId: string;
    verifyToken: string;
  };
  emailTemplates: {
    taskAssigned: string;
    taskCompleted: string;
    pendingVerification: string;
  };
}

export interface AuthContext {
  user: User | null;
  loading: boolean;
}
