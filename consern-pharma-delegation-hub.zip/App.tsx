
import React, { useState, useEffect } from 'react';
import { User, Task, TaskStatus } from './types';
import { db } from './services/db';
import Layout from './components/Layout';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import Tasks from './components/Tasks';
import UserManagement from './components/Admin';
import Settings from './components/Settings';
import { ShieldCheck, CheckCircle, AlertCircle } from 'lucide-react';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [verificationModal, setVerificationModal] = useState<{task: Task, valid: boolean} | null>(null);

  useEffect(() => {
    db.initialize();
    const session = localStorage.getItem('delegation_hub_session');
    if (session) {
      const users = db.getUsers();
      const found = users.find(u => u.email === session);
      if (found && found.status === 'Active') {
        setUser(found);
      } else {
        localStorage.removeItem('delegation_hub_session');
      }
    }
    setLoading(false);

    // Handle Deep Link for Verification
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#verify/')) {
        const parts = hash.split('/');
        if (parts.length === 3) {
          const taskId = parts[1];
          const token = parts[2];
          const tasks = db.getTasks();
          const task = tasks.find(t => t.id === taskId);
          if (task && task.verificationToken === token && task.status === TaskStatus.PENDING_VERIFICATION) {
            setVerificationModal({ task, valid: true });
          } else {
            setVerificationModal(task ? { task, valid: false } : null);
          }
        }
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const handleLogin = (loggedInUser: User) => {
    localStorage.setItem('delegation_hub_session', loggedInUser.email);
    setUser(loggedInUser);
  };

  const handleLogout = () => {
    localStorage.removeItem('delegation_hub_session');
    setUser(null);
  };

  const finalizeVerification = () => {
    if (verificationModal?.task) {
      db.updateTask(verificationModal.task.id, { 
        status: TaskStatus.COMPLETED, 
        verifiedAt: new Date().toISOString() 
      });
      setVerificationModal(null);
      window.location.hash = '';
      setActiveTab('dashboard');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent"></div>
      </div>
    );
  }

  if (!user) {
    return <Auth onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard user={user} />;
      case 'my-tasks':
        return <Tasks user={user} view="my-tasks" />;
      case 'delegated':
        return <Tasks user={user} view="delegated" />;
      case 'verification':
        return <Tasks user={user} view="verification" />;
      case 'users':
        return <UserManagement />;
      case 'settings':
        return <Settings />;
      case 'reports':
        return <Dashboard user={user} />;
      default:
        return (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <h2 className="text-2xl font-bold mb-2">Coming Soon</h2>
            <p>The {activeTab} module is under development.</p>
          </div>
        );
    }
  };

  return (
    <Layout 
      user={user} 
      onLogout={handleLogout} 
      activeTab={activeTab} 
      setActiveTab={setActiveTab}
    >
      {renderContent()}

      {/* Verification Deep Link Modal */}
      {verificationModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-md p-4">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden p-8 text-center animate-in zoom-in-95 duration-300">
            <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full mb-6 ${verificationModal.valid ? 'bg-blue-100 text-blue-600' : 'bg-red-100 text-red-600'}`}>
              {verificationModal.valid ? <ShieldCheck className="w-10 h-10" /> : <AlertCircle className="w-10 h-10" />}
            </div>
            
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {verificationModal.valid ? 'Secure Verification' : 'Invalid Link'}
            </h2>
            
            {verificationModal.valid ? (
              <>
                <p className="text-gray-500 mb-8 leading-relaxed">
                  You are verifying task <span className="font-bold text-gray-800">"{verificationModal.task.title}"</span>. 
                  This action is permanent and will close the task across the enterprise.
                </p>
                <div className="flex flex-col gap-3">
                  <button
                    onClick={finalizeVerification}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-xl shadow-blue-100 flex items-center justify-center gap-2 transition-all active:scale-95"
                  >
                    <CheckCircle className="w-5 h-5" />
                    Approve & Verify
                  </button>
                  <button
                    onClick={() => { setVerificationModal(null); window.location.hash = ''; }}
                    className="w-full bg-gray-50 text-gray-500 font-bold py-4 rounded-2xl hover:bg-gray-100 transition-all"
                  >
                    Not Now
                  </button>
                </div>
              </>
            ) : (
              <>
                <p className="text-gray-500 mb-8 leading-relaxed">
                  This verification link is expired, used, or invalid. Please request a new link from the delegator.
                </p>
                <button
                  onClick={() => { setVerificationModal(null); window.location.hash = ''; }}
                  className="w-full bg-gray-900 text-white font-bold py-4 rounded-2xl transition-all active:scale-95"
                >
                  Return to Dashboard
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </Layout>
  );
};

export default App;
