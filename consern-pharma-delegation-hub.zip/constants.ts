
import { Priority, TaskStatus } from './types';

export const PRIORITY_COLORS = {
  [Priority.LOW]: 'bg-blue-100 text-blue-700 border-blue-200',
  [Priority.MEDIUM]: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  [Priority.HIGH]: 'bg-orange-100 text-orange-700 border-orange-200',
  [Priority.CRITICAL]: 'bg-red-100 text-red-700 border-red-200',
};

export const STATUS_COLORS = {
  [TaskStatus.OPEN]: 'bg-gray-100 text-gray-700',
  [TaskStatus.IN_PROGRESS]: 'bg-blue-100 text-blue-700',
  [TaskStatus.PENDING_VERIFICATION]: 'bg-purple-100 text-purple-700',
  [TaskStatus.COMPLETED]: 'bg-green-100 text-green-700',
  [TaskStatus.OVERDUE]: 'bg-red-100 text-red-700',
};

export const APP_NAME = "DelegationHub";
